
This is really just a collection of JavaScript functions/classes/scripts currently for personal use.
Some of them are waiting to be factored out into their own modules, but without a concrete time line.
